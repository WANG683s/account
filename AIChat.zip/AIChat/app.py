"""支持手机号密码登录的多人独立账本，可部署至 Render。"""

from __future__ import annotations

import os
import re
import secrets
import sqlite3
from datetime import date, datetime, timedelta
from decimal import Decimal, InvalidOperation
from functools import wraps
from pathlib import Path
from typing import Callable

from flask import Flask, abort, flash, g, jsonify, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

APP_DIR = Path(__file__).parent
DATABASE_URL = os.environ.get("DATABASE_URL", "")
DATABASE_PATH = Path(os.environ.get("DATABASE_PATH", APP_DIR / "ledger.db"))
DEFAULT_PLATFORMS = ("微信支付", "支付宝", "云闪付", "银行卡", "信用卡", "现金", "其他")
PHONE_PATTERN = re.compile(r"^1[3-9]\d{9}$")

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.environ.get("SECRET_KEY") or secrets.token_urlsafe(48),
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SESSION_COOKIE_SECURE", "false").lower() == "true",
    PERMANENT_SESSION_LIFETIME=timedelta(days=14),
)


class Database:
    """统一 SQLite 与 PostgreSQL 的最小查询接口。"""

    def __init__(self):
        self.postgres = bool(DATABASE_URL)
        if self.postgres:
            import psycopg
            from psycopg.rows import dict_row
            self.connection = psycopg.connect(DATABASE_URL, row_factory=dict_row)
        else:
            self.connection = sqlite3.connect(DATABASE_PATH)
            self.connection.row_factory = sqlite3.Row
            self.connection.execute("PRAGMA foreign_keys = ON")

    def execute(self, query: str, params: tuple = ()): 
        if self.postgres:
            query = query.replace("?", "%s")
        return self.connection.execute(query, params)

    def __enter__(self):
        return self

    def __exit__(self, error_type, error, traceback):
        if error_type:
            self.connection.rollback()
        else:
            self.connection.commit()
        self.connection.close()


def db() -> Database:
    return Database()


def is_postgres() -> bool:
    return bool(DATABASE_URL)


def init_db() -> None:
    auto_id = "BIGSERIAL PRIMARY KEY" if is_postgres() else "INTEGER PRIMARY KEY"
    with db() as connection:
        connection.execute(f"""
            CREATE TABLE IF NOT EXISTS users (
                id {auto_id}, phone TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                last_login_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
        connection.execute(f"""
            CREATE TABLE IF NOT EXISTS platforms (
                id {auto_id}, name TEXT UNIQUE NOT NULL,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            )""")
        connection.execute(f"""
            CREATE TABLE IF NOT EXISTS transactions (
                id {auto_id}, occurred_on TEXT NOT NULL, amount_cents INTEGER NOT NULL,
                kind TEXT NOT NULL CHECK(kind IN ('expense','income')), category TEXT NOT NULL,
                platform_id INTEGER, merchant TEXT, note TEXT,
                created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, user_id INTEGER,
                FOREIGN KEY(platform_id) REFERENCES platforms(id), FOREIGN KEY(user_id) REFERENCES users(id)
            )""")
        if not is_postgres():
            columns = {row["name"] for row in connection.execute("PRAGMA table_info(transactions)").fetchall()}
            if "user_id" not in columns:
                connection.execute("ALTER TABLE transactions ADD COLUMN user_id INTEGER")
        connection.execute("CREATE INDEX IF NOT EXISTS ix_transactions_user_date ON transactions(user_id, occurred_on)")
        connection.execute("CREATE INDEX IF NOT EXISTS ix_transactions_user_created ON transactions(user_id, created_at DESC, id DESC)")
        for name in DEFAULT_PLATFORMS:
            if is_postgres():
                connection.execute("INSERT INTO platforms(name) VALUES (?) ON CONFLICT (name) DO NOTHING", (name,))
            else:
                connection.execute("INSERT OR IGNORE INTO platforms(name) VALUES(?)", (name,))


def csrf_token() -> str:
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


@app.context_processor
def template_context() -> dict:
    return {"csrf_token": csrf_token, "current_user": getattr(g, "user", None)}


def csrf_protected(view: Callable):
    @wraps(view)
    def wrapped(*args, **kwargs):
        submitted = request.form.get("csrf_token", "")
        if not submitted or not secrets.compare_digest(submitted, session.get("csrf_token", "")):
            abort(400, "请求校验失败，请刷新页面后重试。")
        return view(*args, **kwargs)
    return wrapped


def login_required(view: Callable):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user_id = session.get("user_id")
        if not user_id:
            if request.path.startswith("/api/"):
                return jsonify({"ok": False, "message": "登录已失效，请重新登录。"}), 401
            return redirect(url_for("login"))
        with db() as connection:
            g.user = connection.execute("SELECT id, phone FROM users WHERE id = ?", (user_id,)).fetchone()
        if not g.user:
            session.clear()
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped


def validate_phone(phone: str) -> str:
    phone = phone.strip()
    if not PHONE_PATTERN.fullmatch(phone):
        raise ValueError("请输入有效的 11 位中国大陆手机号。")
    return phone


def add_transaction(data, user_id: int) -> None:
    try:
        occurred_on = datetime.strptime(data.get("date", ""), "%Y-%m-%d").date().isoformat()
        amount = Decimal(data.get("amount", "")).quantize(Decimal("0.01"))
    except (ValueError, InvalidOperation) as error:
        raise ValueError("请填写有效的日期和金额。") from error
    if amount <= 0:
        raise ValueError("金额必须大于 0。")
    kind = data.get("kind", "expense")
    if kind not in ("expense", "income"):
        raise ValueError("收支类型无效。")
    platform_id = data.get("platform_id") or None
    with db() as connection:
        if platform_id and not connection.execute("SELECT 1 FROM platforms WHERE id = ?", (platform_id,)).fetchone():
            raise ValueError("支付方式无效。")
        connection.execute("""INSERT INTO transactions(occurred_on, amount_cents, kind, category, platform_id, merchant, note, user_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", (occurred_on, int(amount * 100), kind, (data.get("category") or "其他").strip()[:30], platform_id, "", (data.get("note") or "").strip()[:200], user_id))


@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("user_id"):
        return redirect(url_for("index"))
    if request.method == "POST":
        try:
            phone, password = validate_phone(request.form.get("phone", "")), request.form.get("password", "")
            with db() as connection:
                user = connection.execute("SELECT id, password_hash FROM users WHERE phone = ?", (phone,)).fetchone()
                if not user or not check_password_hash(user["password_hash"], password):
                    raise ValueError("手机号或密码错误。")
                connection.execute("UPDATE users SET last_login_at = CURRENT_TIMESTAMP WHERE id = ?", (user["id"],))
            session.clear(); session["user_id"] = user["id"]; session.permanent = True; csrf_token()
            return redirect(url_for("index"))
        except ValueError as error:
            flash(str(error), "error")
    return render_template("login.html", mode="login")


@app.route("/register", methods=["GET", "POST"])
def register():
    if session.get("user_id"):
        return redirect(url_for("index"))
    if request.method == "POST":
        try:
            phone, password, confirm = validate_phone(request.form.get("phone", "")), request.form.get("password", ""), request.form.get("confirm_password", "")
            if len(password) < 8: raise ValueError("密码至少需要 8 个字符。")
            if password != confirm: raise ValueError("两次输入的密码不一致。")
            with db() as connection:
                try:
                    if is_postgres():
                        cursor = connection.execute("INSERT INTO users(phone, password_hash) VALUES (?, ?) RETURNING id", (phone, generate_password_hash(password)))
                        user_id = cursor.fetchone()["id"]
                    else:
                        cursor = connection.execute("INSERT INTO users(phone, password_hash) VALUES (?, ?)", (phone, generate_password_hash(password)))
                        user_id = cursor.lastrowid
                except Exception as error:
                    if "unique" in str(error).lower(): raise ValueError("该手机号已经注册，请直接登录。") from error
                    raise
            session.clear(); session["user_id"] = user_id; session.permanent = True; csrf_token()
            return redirect(url_for("index"))
        except ValueError as error:
            flash(str(error), "error")
    return render_template("login.html", mode="register")


@app.post("/logout")
@login_required
@csrf_protected
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.get("/")
@login_required
def index():
    return render_dashboard(date.today().strftime("%Y-%m"), g.user["id"])


@app.post("/api/transactions")
@login_required
@csrf_protected
def create_transaction():
    try:
        add_transaction(request.form, g.user["id"])
    except ValueError as error:
        return jsonify({"ok": False, "message": str(error)}), 400
    selected_date = request.form.get("date", "")[:10]
    return jsonify({"ok": True, "message": "记录成功", "redirect": url_for("ledger", period="month", selected_date=selected_date)})


@app.post("/transactions/<int:transaction_id>/delete")
@login_required
@csrf_protected
def delete_transaction(transaction_id: int):
    with db() as connection:
        result = connection.execute("DELETE FROM transactions WHERE id = ? AND user_id = ?", (transaction_id, g.user["id"]))
    flash("账目已删除。" if result.rowcount else "未找到可删除的账目。", "success" if result.rowcount else "error")
    return redirect(url_for("ledger", period=request.form.get("period", "month"), selected_date=request.form.get("selected_date", "")))


@app.get("/ledger")
@login_required
def ledger():
    period = request.args.get("period", "month")
    period = period if period in ("day", "week", "month") else "month"
    try: selected_date = datetime.strptime(request.args.get("selected_date", ""), "%Y-%m-%d").date()
    except ValueError: selected_date = date.today()
    if period == "day":
        start_date, end_date, period_label = selected_date, selected_date + timedelta(days=1), selected_date.strftime("%Y 年 %m 月 %d 日")
    elif period == "week":
        start_date = selected_date - timedelta(days=selected_date.weekday()); end_date = start_date + timedelta(days=7)
        period_label = f"{start_date.strftime('%Y 年 %m 月 %d 日')} 至 {(end_date - timedelta(days=1)).strftime('%m 月 %d 日')}"
    else:
        start_date = selected_date.replace(day=1); end_date = (start_date.replace(day=28) + timedelta(days=4)).replace(day=1); period_label = start_date.strftime("%Y 年 %m 月")
    start, end = start_date.isoformat(), end_date.isoformat()
    with db() as connection:
        transactions = connection.execute("""SELECT t.*, p.name AS platform, substr(t.occurred_on, 1, 16) AS display_time FROM transactions t LEFT JOIN platforms p ON t.platform_id = p.id WHERE t.user_id = ? AND t.occurred_on >= ? AND t.occurred_on < ? ORDER BY t.created_at DESC, t.id DESC""", (g.user["id"], start, end)).fetchall()
        totals = connection.execute("""SELECT COALESCE(SUM(CASE WHEN kind = 'expense' THEN amount_cents ELSE 0 END), 0) AS expenses, COALESCE(SUM(CASE WHEN kind = 'income' THEN amount_cents ELSE 0 END), 0) AS income FROM transactions WHERE user_id = ? AND occurred_on >= ? AND occurred_on < ?""", (g.user["id"], start, end)).fetchone()
        rows = connection.execute("SELECT kind, category, SUM(amount_cents) AS amount FROM transactions WHERE user_id = ? AND occurred_on >= ? AND occurred_on < ? GROUP BY kind, category ORDER BY amount DESC", (g.user["id"], start, end)).fetchall()
    expense_categories = [{"name": row["category"], "amount": row["amount"] / 100} for row in rows if row["kind"] == "expense"]
    income_categories = [{"name": row["category"], "amount": row["amount"] / 100} for row in rows if row["kind"] == "income"]
    return render_template("ledger.html", month=start[:7], selected_date=selected_date.isoformat(), period=period, period_label=period_label, transactions=transactions, totals=totals, expense_categories=expense_categories, income_categories=income_categories)


def render_dashboard(month: str, user_id: int):
    start = f"{month}-01"
    with db() as connection:
        platforms = connection.execute("SELECT id, name FROM platforms ORDER BY CASE name WHEN '微信支付' THEN 1 WHEN '支付宝' THEN 2 WHEN '云闪付' THEN 3 WHEN '银行卡' THEN 4 WHEN '信用卡' THEN 5 WHEN '现金' THEN 6 WHEN '其他' THEN 7 END").fetchall()
        transactions = connection.execute("""SELECT t.*, p.name AS platform, substr(t.occurred_on, 1, 16) AS display_time FROM transactions t LEFT JOIN platforms p ON t.platform_id = p.id WHERE t.user_id = ? AND t.occurred_on >= ? AND t.occurred_on < date(?, '+1 month') ORDER BY t.created_at DESC, t.id DESC""", (user_id, start, start)).fetchall()
        totals = connection.execute("""SELECT COALESCE(SUM(CASE WHEN kind = 'expense' THEN amount_cents ELSE 0 END), 0) AS expenses, COALESCE(SUM(CASE WHEN kind = 'income' THEN amount_cents ELSE 0 END), 0) AS income FROM transactions WHERE user_id = ? AND occurred_on >= ? AND occurred_on < date(?, '+1 month')""", (user_id, start, start)).fetchone()
    return render_template("index.html", month=month, today=date.today().isoformat(), platforms=platforms, transactions=transactions, totals=totals)


@app.get("/healthz")
def healthz():
    return {"status": "ok"}


init_db()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
