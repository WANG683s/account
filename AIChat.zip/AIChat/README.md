# 轻记账：Render 公网部署版

这是一个多人独立网页账本。用户使用手机号和密码注册，每位用户只能访问自己的账目。

## 本机运行

```cmd
python -m pip install -r requirements.txt
python app.py
```

浏览器打开：<http://127.0.0.1:5000>

## 部署到 Render

### 1. 上传到 GitHub 私有仓库

不要上传以下文件：

- `ledger.db`
- `.env`
- 任何密码或密钥

项目提供了 `.gitignore`，会忽略这些本地文件。

### 2. 创建 Render Blueprint

1. 注册并登录 Render。
2. 点击 **New** → **Blueprint**。
3. 连接 GitHub，并选择本项目的私有仓库。
4. Render 会读取仓库中的 `render.yaml`，创建：
   - `light-ledger` Web Service
   - `light-ledger-db` PostgreSQL 数据库
5. 确认创建并等待部署完成。

部署成功后，Render 会提供 HTTPS 链接，例如：

```text
https://light-ledger.onrender.com
```

将该链接发给其他人即可。用户注册后只能看到自己的账本。

### 3. 环境变量

`render.yaml` 会自动生成 `SECRET_KEY`、启用安全 Cookie，并把 PostgreSQL 的连接地址赋给 `DATABASE_URL`。

如手动创建服务，需要在 Render 的 Environment 中设置：

```text
SECRET_KEY=高强度随机字符串
DATABASE_URL=PostgreSQL 连接地址
SESSION_COOKIE_SECURE=true
```

生产启动命令：

```text
gunicorn --bind 0.0.0.0:$PORT app:app
```

## 使用与安全说明

- 手机号仅作为账号标识；密码只保存加密哈希，不保存明文。
- 一个手机号只能注册一次。请使用至少 8 个字符的密码。
- 登录状态默认保留 14 天，点击“退出”可清除当前设备的登录状态。
- 公网部署时必须使用 HTTPS；Render 提供的 `onrender.com` 地址默认支持 HTTPS。
- 免费托管服务和免费数据库可能有休眠、额度或数据保留限制。请定期备份重要数据。
- 项目中旧的未绑定账目不会分配或展示给任何新注册用户。
