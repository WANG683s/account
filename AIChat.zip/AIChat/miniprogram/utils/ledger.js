const STORAGE_KEY = 'minimal_ledger_records'

function getRecords() {
  return wx.getStorageSync(STORAGE_KEY) || []
}

function addRecord(record) {
  const records = getRecords()
  records.unshift({
    id: `${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    createdAt: Date.now(),
    ...record,
    createdAt: Date.now()
  })
  wx.setStorageSync(STORAGE_KEY, records)
}

function getSummary() {
  return getRecords().reduce((summary, record) => {
    const amount = Number(record.amount) || 0
    if (record.type === 'income') summary.income += amount
    if (record.type === 'expense') summary.expense += amount
    return summary
  }, { income: 0, expense: 0 })
}

function formatAmount(amount) {
  return (Number(amount) || 0).toFixed(2)
}

module.exports = { addRecord, getRecords, getSummary, formatAmount }
