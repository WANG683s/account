App({
  globalData: {
    ledgerKey: 'minimal_ledger_records'
  }
})
