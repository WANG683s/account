const { addRecord } = require('../../utils/ledger')

Page({
  data: {
    amount: '', category: '餐饮', note: '', date: '',
    categories: [
      { name: '餐饮', icon: '☕' }, { name: '交通', icon: '▣' }, { name: '购物', icon: '▢' },
      { name: '娱乐', icon: '♫' }, { name: '住房', icon: '⌂' }, { name: '医疗', icon: '♡' },
      { name: '教育', icon: '▤' }, { name: '其他', icon: '•••' }
    ]
  },
  onLoad() { this.setData({ date: this.today() }) },
  today() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` },
  inputAmount(e) { this.setData({ amount: e.detail.value }) },
  inputNote(e) { this.setData({ note: e.detail.value }) },
  inputDate(e) { this.setData({ date: e.detail.value }) },
  chooseCategory(e) { this.setData({ category: e.currentTarget.dataset.name }) },
  save() {
    const amount = Number(this.data.amount)
    if (!amount || amount <= 0) return wx.showToast({ title: '请输入正确金额', icon: 'none' })
    addRecord({ type: 'expense', amount, purpose: this.data.category, note: this.data.note.trim(), date: this.data.date })
    wx.showToast({ title: '已记一笔支出', icon: 'success' })
    setTimeout(() => wx.navigateBack(), 500)
  }
})
