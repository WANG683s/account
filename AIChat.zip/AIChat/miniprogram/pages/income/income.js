const { addRecord } = require('../../utils/ledger')

Page({
  data: {
    amount: '', category: '工资', note: '', date: '',
    categories: [
      { name: '工资', icon: '¥' }, { name: '奖金', icon: '★' }, { name: '兼职', icon: '□' },
      { name: '投资', icon: '↗' }, { name: '退款', icon: '↩' }, { name: '礼金', icon: '♡' },
      { name: '报销', icon: '▤' }, { name: '其他', icon: '•••' }
    ]
  },
  onLoad() { this.setData({ date: this.today() }) },
  today() { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}` },
  inputAmount(e) { this.setData({ amount: e.detail.value }) },
  inputNote(e) { this.setData({ note: e.detail.value }) },
  inputDate(e) { this.setData({ date: e.detail.value }) },
  chooseCategory(e) { this.setData({ category: e.currentTarget.dataset.name }) },
  save() {
    const amount = Number(this.data.amount)
    if (!amount || amount <= 0) return wx.showToast({ title: '请输入正确金额', icon: 'none' })
    addRecord({ type: 'income', amount, purpose: this.data.category, note: this.data.note.trim(), date: this.data.date })
    wx.showToast({ title: '已记一笔收入', icon: 'success' })
    setTimeout(() => wx.navigateBack(), 500)
  }
})
