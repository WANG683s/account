const { getRecords, getSummary, formatAmount } = require('../../utils/ledger')

Page({
  data: { income: '0.00', expense: '0.00', balance: '0.00', records: [] },
  onShow() { this.refresh() },
  refresh() {
    const summary = getSummary()
    this.setData({
      income: formatAmount(summary.income),
      expense: formatAmount(summary.expense),
      balance: formatAmount(summary.income - summary.expense),
      records: getRecords().slice(0, 5).map(item => ({
        ...item,
        amount: formatAmount(item.amount),
        date: item.date || new Date(item.createdAt).toLocaleDateString('zh-CN', { month: 'numeric', day: 'numeric' })
      }))
    })
  },
  goExpense() { wx.navigateTo({ url: '/pages/expense/expense' }) },
  goIncome() { wx.navigateTo({ url: '/pages/income/income' }) }
})
